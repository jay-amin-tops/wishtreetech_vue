<template>
  <div class="home">
   About us page
  </div>
</template>

<script>
export default {
  name: "About-page",
  
};
</script>
