<template>
  <div class="home">
  Home page
  </div>
</template>

<script>
export default {
  name: "Home-page",
  
};
</script>
