import { createRouter, createWebHistory } from 'vue-router'
import Home from './components/Home'
import About from './components/About'

const routes = [
    {
        path: '/',
        name: 'Home-page',
        component: Home
    },
    {
        path: '/about',
        name: 'About-page',
        component: About
    }
]

const router = createRouter({ history: createWebHistory(), routes })
export default router

// router/index.js
// import { createRouter, createWebHistory } from 'vue-router'
// import Home from '@/views/Home.vue'
// import Cats from '@/views/Cats.vue'

// const routes = [
//     {
//         path: '/',
//         name: 'Home',
//         component: Home
//     },
//     {
//         path: '/cats',
//         name: 'Cats',
//         component: Cats
//     }
// ]

// const router = createRouter({ history: createWebHistory(), routes })
// export default router